	<div class="left-side-bar">
		<div class="brand-logo">
			<a href="index.php">
			<h6>Aplikasi voucher</h6>
			</a>
		</div>
		<div class="menu-block customscroll">
			<div class="sidebar-menu">
				<ul id="accordion-menu">
					<li>
						<a href="http://digitalcerita.wordpress.com" class="dropdown-toggle no-arrow">
							<span class="fa fa-map-o"></span><span class="mtext">About</span>
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>