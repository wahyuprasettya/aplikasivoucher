

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form method="post" action="proses.php">
<label>Kode Voucher</label> <br>
<input type="text" name="kode" placeholder="Masukan Kode Voucher"> <br>
<label>Total Pembayaran</label><br>
<input type="text" name="jumlbyar" placeholder="Masukan jumlah bayar"><br><br>
<input type="submit" name="proses" value="beli">

</form>

</body>
</html>



